# Ukashah Platform — Android APK Project

This is the Android Studio project structure for the Ukashah Platform V2 web app wrapped in a native Android WebView.

## Open
Open the `Ukashah_Android` folder in Android Studio.

## Build APK
Use Android Studio:
Build → Generate App Bundles or APKs → Generate APKs

Debug APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Main package
`com.ukashah.platform`

## App label
`Ukashah Platform`

## Included
- Customer management
- Product management
- Dealer price / retail price
- Multi-product orders
- Automatic totals and profit
- Invoice
- WhatsApp sharing
- Order history
- Status tracking
- Reports
- Local browser storage

For production release, add a proper launcher icon, signed release keystore, privacy policy, cloud database/login, and a real backend if data must sync between devices.
